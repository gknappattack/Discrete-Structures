//
// Created by Gregory Knapp on 7/14/20.
//

#ifndef LAB2_TUPLE_H
#define LAB2_TUPLE_H

#include <vector>
#include <iostream>
using namespace std;


class Tuple : public std::vector<string> {
public:
    void toString() const;
private:

};


#endif //LAB2_TUPLE_H
