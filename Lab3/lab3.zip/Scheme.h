//
// Created by Gregory Knapp on 7/16/20.
//

#ifndef LAB2_SCHEME_H
#define LAB2_SCHEME_H

#include <vector>
#include <iostream>
using namespace std;


class Scheme : public std::vector<string> {
public:
private:
};

#endif //LAB2_SCHEME_H
